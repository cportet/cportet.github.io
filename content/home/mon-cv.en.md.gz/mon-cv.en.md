﻿Are you looking for my **resume**? 
You can find it on [this page](/resume).