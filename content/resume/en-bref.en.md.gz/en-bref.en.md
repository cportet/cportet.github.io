﻿At the age of <v-age>, originally from Picardy, I live in the Rhône region.<br />
I am married and the father of 3 children.

Software craftsman, with over <v-anciennete> years of experience,
I have held various roles: Technical Manager, Project Manager, or Developer.

I have worked on many types of solutions, ranging from client/server development to web applications,
mainly on Microsoft technologies, using modern frameworks like .Net Core and Blazor WASM.

With solid experience in project and team management, software architecture, and a good understanding
of business issues and work processes, I have worked in several sectors, such as industry, services,
public administration, and software publishing.

I am open to new opportunities and collaborations.