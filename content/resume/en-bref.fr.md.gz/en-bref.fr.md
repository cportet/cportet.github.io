﻿Âgé de <v-age> ans, originaire de Picardie, je vis dans le Rhône.<br />
Je suis marié et père de 3 enfants.

Artisan logiciel, avec plus de <v-anciennete> ans d'expérience,
j'ai occupé de nombreux rôles : Responsable technique, chef de projet ou développeur.

J'ai travaillé sur de nombreux types de solutions, allant du développement client/serveur aux applications web,
principalement sur les technologies Microsoft, en utilisant des frameworks modernes comme .Net Core et Blazor WASM.

Fort d'une solide expérience en gestion de projets et d'équipes, en architecture logicielle et d'une bonne compréhension
des enjeux métiers et des processus de travail, j'ai exercé dans plusieurs secteurs, tels que l'industrie, le service,
l'administration publique, et l'édition de logiciels.

Je suis ouvert à de nouvelles opportunités et collaborations.