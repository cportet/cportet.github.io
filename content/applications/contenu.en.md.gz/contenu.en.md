﻿This section is dedicated to showcasing my applications and projects.

This space is currently (nearly) empty! It will be populated soon. Stay tuned!

### Applications

[My Apps](/Applications/MesApps)

### All Apps on the Windows Store

[Cyril Portet Dev on the Store](https://apps.microsoft.com/search/publisher?name=Cyril+Portet+Dev)

### Privacy Policy

You can find the privacy policy common to all my applications here:  
[Privacy Policy](/Applications/Charte)