﻿Cet espace a pour but de vous présenter mes applications et réalisations.

Cet espace est (relativement) pour l'instant vide ! Il sera alimenté prochainement. Restez à l'écoute !

### Applications

[Mes Apps](/Applications/MesApps)

### Toutes les applications sur le Store Windows

[Cyril Portet Dev sur le Store](https://apps.microsoft.com/search/publisher?name=Cyril+Portet+Dev)

### Charte de confidentialité

Vous pouvez retrouver la charte de confidentialité commune à toutes mes applications ici :
[Charte de confidentialité](/Applications/Charte)
