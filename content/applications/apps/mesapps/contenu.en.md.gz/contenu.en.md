﻿The "My Apps" application was a prototype built with WinUI, designed to create a universal application launcher.

It allowed users to gather and organize all the applications installed on their Windows device within a single, customizable interface.
This application is no longer actively maintained at the moment, but I plan to resume work on the code soon, publish it on GitHub, and update the app on the Microsoft Store.

### Privacy Policy

You can find the privacy policy common to all my applications here:
[Privacy Policy](/Applications/Charte)

### Download

In the meantime, you can still download it here:
[Mes Applications - Microsoft Store](https://www.microsoft.com/store/productId/9p2v5r46n6xq)

<script type="module" src="https://get.microsoft.com/badge/ms-store-badge.bundled.js"></script>
<ms-store-badge
	productid="9p2v5r46n6xq"
	productname="MesApplications"
	window-mode="direct"
	theme="auto"
	size="small"
	language="en-us"
	animation="on">
</ms-store-badge>